package com.fwrt.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class User(
    @PrimaryKey val username: String,
    val password: String,
    val gender: String?,
    val birthday: Long?

    // 可扩展字段如性别、生日等
)
