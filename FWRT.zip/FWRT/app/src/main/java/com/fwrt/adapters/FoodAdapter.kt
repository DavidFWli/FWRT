package com.fwrt.adapters

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fwrt.R
import com.fwrt.databinding.ItemFoodBinding
import com.fwrt.models.Food
import java.text.SimpleDateFormat
import java.util.*

class FoodAdapter(
    private val foodList: List<Food>,
    private val onClick: ((Food) -> Unit)? = null
) : RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    inner class FoodViewHolder(val binding: ItemFoodBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(food: Food) {
            binding.tvFoodName.text = food.name
            binding.tvNutrition.text = "Nutrition: ${food.nutrition}"
            binding.tvPurchaseDate.text = "Purchased: ${formatDate(food.purchaseDate)}"
            binding.tvExpiryDate.text = "Expiry: ${formatDate(food.expiryDate)}"

            val daysLeft = ((food.expiryDate - System.currentTimeMillis()) / (1000 * 60 * 60 * 24)).toInt()
            binding.tvDaysLeft.text = when {
                daysLeft < 0 -> "Expired"
                daysLeft == 0 -> "Expires today"
                else -> "Expires in $daysLeft days"
            }

            // 加载图片（如果 imageUri 是非空字符串）
            try {
                if (food.imageUri.isNotEmpty()) {
                    binding.imgFood.setImageURI(Uri.parse(food.imageUri))
                }
            } catch (_: Exception) {
                // 设置占位图（如图片无效）
                binding.imgFood.setImageResource(R.drawable.ic_food_placeholder)
            }

            binding.root.setOnClickListener {
                onClick?.invoke(food)
            }
        }

        private fun formatDate(millis: Long): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            return sdf.format(Date(millis))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val binding = ItemFoodBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FoodViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        holder.bind(foodList[position])
    }

    override fun getItemCount(): Int = foodList.size
}
