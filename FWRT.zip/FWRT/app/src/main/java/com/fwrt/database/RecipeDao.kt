package com.fwrt.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.fwrt.models.Recipe

@Dao
interface RecipeDao {

    @Insert
    suspend fun insertRecipe(recipe: Recipe)

    @Query("SELECT * FROM Recipe")
    suspend fun getAllRecipes(): List<Recipe>

    @Query("DELETE FROM Recipe WHERE id = :id")
    suspend fun deleteRecipeById(id: Int)
}
