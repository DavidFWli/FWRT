package com.fwrt.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fwrt.databinding.ItemRecipeBinding
import com.fwrt.models.Recipe

class RecipeAdapter(
    private val recipeList: List<Recipe>,
    private val onClick: ((Recipe) -> Unit)? = null
) : RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder>() {

    inner class RecipeViewHolder(val binding: ItemRecipeBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeViewHolder {
        val binding = ItemRecipeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecipeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecipeViewHolder, position: Int) {
        val recipe = recipeList[position]
        with(holder.binding) {
            tvRecipeName.text = recipe.name
            tvIngredients.text = "Ingredients: ${recipe.ingredients}"

            root.setOnClickListener {
                onClick?.invoke(recipe)
            }
        }
    }

    override fun getItemCount(): Int = recipeList.size
}
