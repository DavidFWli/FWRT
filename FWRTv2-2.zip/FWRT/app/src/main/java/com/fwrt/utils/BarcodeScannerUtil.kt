package com.fwrt.utils

import android.app.Activity
import android.content.Intent
import com.google.zxing.integration.android.IntentIntegrator

object BarcodeScannerUtil {

    fun scanBarcode(activity: Activity) {
        val integrator = IntentIntegrator(activity)
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
        integrator.setPrompt("Scan a barcode")
        integrator.setCameraId(0)
        integrator.setBeepEnabled(true)
        integrator.setBarcodeImageEnabled(true)
        integrator.initiateScan()
    }

    fun handleScanResult(activity: Activity, requestCode: Int, resultCode: Int, data: Intent?, onScanned: (String) -> Unit) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null && result.contents != null) {
            onScanned(result.contents)  // 返回扫码结果（字符串）
        }
    }
}
