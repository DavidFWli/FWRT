package com.fwrt.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Recipe(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val ingredients: String   // 示例："番茄:100g, 鸡蛋:1个, 盐:适量"
)
